<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            {{ __('Doctors Schedule') }}
        </h2>
    </x-slot>
    <script src="https://code.highcharts.com/highcharts.js"></script>
    
        
    <div class="py-12">
    <section>
	
		@csrf
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<table class="table">
						  <thead class="thead-dark">
						    <tr>
						      <th>Doctor Name</th>
						      <th>Available Days</th>
						      <th>Available Time</th>
							  <th>Calendar</th>
						      <th>Action</th>
						    </tr>
						  </thead>
						  <tbody>
                        @foreach ($drsched as $drs)
						    <tr class="alert" role="alert">
						      <th scope="row">{{$drs->doctorname}}</th>
						      <td>{{$drs->availabledays}}</td>
						      <td>{{$drs->availabletime}}</td>
							  <td>
							 	<div class="form-group">
									<label for="date">Select a date:</label>
									<input type="text" name="date" class="datepicker form-control">
								</div>
							  </td>
						      <td>
						      	<!--<a href="#" class="close" data-dismiss="alert" aria-label="Close">-->
                                  <button type="button" class="btn btn-primary">Book Now</button>
				        	  </td>
						    </tr>
                        @endforeach
						  </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	
	</section>

    </div>

</x-app-layout>
