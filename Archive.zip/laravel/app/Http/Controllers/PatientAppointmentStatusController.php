<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\patientdoctorlist;

class PatientAppointmentStatusController extends Controller
{
    //
    public function pdrlist()
    {
        //$userData = covid19case::all();
        $plist = patientdoctorlist::all();
        return view('patientappointmentstatus', compact('plist'));
    }
}
