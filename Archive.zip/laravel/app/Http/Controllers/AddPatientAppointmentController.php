<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\doctorpatientlist;

class AddPatientAppointmentController extends Controller
{
    //
    public function doctorpatientlist(Request $request)
    {
        $request->validate([
            'doctorname' => ['required', 'string', 'max:255'],
            'patientname' => ['required', 'string', 'max:255'],
            'department' => ['required', 'string', 'max:255'],
            'appointmentdate' => ['required', 'string', 'max:255'],
            'status' => ['required', 'string', 'max:255'],
        ]);

        $drpatientlist = new doctorpatientlist();       
        $drpatientlist->patientid = 11;
        $drpatientlist->doctorid = 11;
        $drpatientlist->doctorname = $request->doctorname;
        $drpatientlist->patientname = $request->patientname;
        $drpatientlist->department = $request->department;
        $drpatientlist->appointmentdate = $request->appointmentdate;
        $drpatientlist->status = $request->status;  
        $res = $drpatientlist->save();

        return back()->with("success", "Records saved successfully");
        //return redirect()->route('patientrecords')->with('success', 'records saved successfully');

    }
}
