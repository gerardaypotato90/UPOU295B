<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\doctorsschedule;
use App\Models\doctorslist;

class docscheduleController extends Controller
{
    //
    public function docsched($doc_sched)
    {
        $drsched =  DB::select('select * from doctorslists where doctorid ='.$doc_sched.'');
        return view('doctorschedule', compact('drsched'));
    }
}
