<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\doctorpatientlist;

class DoctorAppointmentController extends Controller
{
    //
    public function drplist()
    {
        //$userData = covid19case::all();
        $dplist = doctorpatientlist::all();
        return view('doctorsappointment', compact('dplist'));
    }
}
