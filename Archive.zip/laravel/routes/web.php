<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group(['middleware' => 'auth'], function() {
    Route::get('/patientdashboard', function () {
        return view('patientdashboard');
    })->name('patientdashboard');
    Route::get('/docdashboard', function () {
        return view('docdashboard');
    })->name('docdashboard');
    Route::get('/admindashboard', function () {
        return view('admindashboard');
    })->name('admindashboard');
    Route::get('/patientappointment', function () {
        return view('patientappointment');
    })->name('patientappointment');
    //Route::get('/patientrecords', function () {
        //return view('patientrecords');
    //})->name('patientrecords');
    Route::get('/scheduleappointment', [\App\Http\Controllers\ScheduleAppointmentController::class, 'doclist'])
        ->name('scheduleappointment.doclist');
    Route::get('/doctorschedule/{id}', [\App\Http\Controllers\docscheduleController::class, 'docsched'])->name('doctorschedule');
    Route::get('/patientappointmentstatus', [\App\Http\Controllers\PatientAppointmentStatusController::class, 'pdrlist'])->name('patientappointmentstatus');
    Route::get('/doctorsappointment', [\App\Http\Controllers\DoctorAppointmentController::class, 'drplist'])->name('doctorsappointment');

    Route::view('patientprofile', 'patientprofile')->name('patientprofile');
    Route::put('patientprofile', [\App\Http\Controllers\ProfileController::class, 'update'])
        ->name('patientprofile.update');

    Route::view('addpatientappointment', 'addpatientappointment')->name('addpatientappointment');
    Route::put('addpatientappointment', [\App\Http\Controllers\AddPatientAppointmentController::class, 'doctorpatientlist'])
        ->name('addpatientappointment.doctorpatientlist');

    Route::view('docprofile', 'docprofile')->name('docprofile');
    Route::put('docprofile', [\App\Http\Controllers\DocProfileController::class, 'docprofile'])
        ->name('docprofile.update');

   


    
   
});

require __DIR__.'/auth.php';